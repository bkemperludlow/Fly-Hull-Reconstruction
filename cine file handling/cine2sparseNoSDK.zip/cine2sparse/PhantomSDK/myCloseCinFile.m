function myCloseCinFile (cindata)

% see http://www.visionresearch.com/phantomzone/viewtopic.php?f=54&t=1271

PhDestroyCine(cindata.cineHandle);

end